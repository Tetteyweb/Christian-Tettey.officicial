document.addEventListener('DOMContentLoaded', function() {
    if (window.location.pathname.endsWith('search.html') && !localStorage.getItem('authenticated')) {
        window.location.href = 'index.html';
    }
});

function handleLogin(event) {
    event.preventDefault();
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    
    // Simulated login (replace with actual authentication logic)
    if (email && password) {
        localStorage.setItem('authenticated', true);
        window.location.href = 'search.html';
    } else {
        alert('Invalid login credentials');
    }
}

function handleSignUp(event) {
    event.preventDefault();
    const email = document.getElementById('signUpEmail').value;
    const password = document.getElementById('signUpPassword').value;
    
    // Simulated sign-up (replace with actual sign-up logic)
    if (email && password) {
        localStorage.setItem('authenticated', true);
        window.location.href = 'search.html';
    } else {
        alert('Sign up failed');
    }
}

function handleSearch(event) {
    event.preventDefault();
    const query = document.getElementById('searchQuery').value;
    window.open(`https://www.google.com/search?q=${encodeURIComponent(query)}`, '_blank');
}